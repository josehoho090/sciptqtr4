// Import Firebase modules
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-auth.js";
import { getStorage, ref, listAll, getDownloadURL } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-storage.js";

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDF4yy2NKe4IyY4-Bm-x_M0Jr59e4_WNbM",
  authDomain: "sciptqtr4group4.firebaseapp.com",
  projectId: "sciptqtr4group4",
  storageBucket: "sciptqtr4group4.appspot.com",
  messagingSenderId: "959939785334",
  appId: "1:959939785334:web:8187f0f4a45c7285732557",
  measurementId: "G-DM8S9QC2WT"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const storage = getStorage(app);

const loginStatus = document.getElementById("loginStatus");
const imageStatus = document.getElementById("imageStatus");
const gallery = document.getElementById("gallery");

onAuthStateChanged(auth, (user) => {
  if (user) {
    loginStatus.textContent = "Logged in as " + user.displayName;
    loadImages();
  } else {
    loginStatus.textContent = "Not logged in. Logging in...";
    const provider = new GoogleAuthProvider();
    signInWithPopup(auth, provider)
      .then((result) => {
        loginStatus.textContent = "Logged in as " + result.user.displayName;
        loadImages();
      })
      .catch((error) => {
        loginStatus.textContent = "Login failed: " + error.message;
        console.error(error);
      });
  }
});

function loadImages() {
  const listRef = ref(storage, 'images/');
  listAll(listRef)
    .then((res) => {
      imageStatus.textContent = "Images loaded:";
      if (res.items.length === 0) {
        gallery.innerHTML = "<p>No images found.</p>";
      }
      res.items.forEach((itemRef) => {
        getDownloadURL(itemRef).then((url) => {
          const img = document.createElement("img");
          img.src = url;
          img.style.width = "200px";
          img.style.margin = "10px";
          gallery.appendChild(img);
        });
      });
    })
    .catch((error) => {
      imageStatus.textContent = "Failed to load images: " + error.message;
      console.error(error);
    });
}
