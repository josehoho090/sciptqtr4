
// Your Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDF4yy2NKe4IyY4-Bm-x_M0Jr59e4_WNdM",
  authDomain: "sciptqtr4group4.firebaseapp.com",
  projectId: "sciptqtr4group4",
  storageBucket: "sciptqtr4group4.appspot.com",
  messagingSenderId: "959939785334",
  appId: "1:959939785334:web:8187f0f4a45c7285732557",
  measurementId: "G-DM8S9QC2WT"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const storage = firebase.storage();

// Auth login with Google popup
auth.signInWithPopup(new firebase.auth.GoogleAuthProvider())
  .then(result => {
    document.getElementById('login-status').innerText = "Logged in as " + result.user.displayName;
    loadImages();
  })
  .catch(error => {
    document.getElementById('login-status').innerText = "Login failed: " + error.message;
  });

// Load and display images
function loadImages() {
  const imageList = document.getElementById("image-list");
  const storageRef = storage.ref();

  storageRef.listAll().then(result => {
    result.items.forEach(imgRef => {
      imgRef.getDownloadURL().then(url => {
        const div = document.createElement("div");
        div.className = "image-item";
        const img = document.createElement("img");
        img.src = url;
        div.appendChild(img);
        imageList.appendChild(div);
      });
    });
  }).catch(err => {
    imageList.innerHTML = "Failed to load images: " + err.message;
  });
}
